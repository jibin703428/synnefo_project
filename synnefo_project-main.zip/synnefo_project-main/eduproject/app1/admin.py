from django.contrib import admin

from .models import task

admin.site.register(task)
